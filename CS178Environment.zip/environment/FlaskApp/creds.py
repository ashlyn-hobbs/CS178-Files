host = 'lab10.cn9nbw41gsla.us-east-1.rds.amazonaws.com'
user = 'admin'
password = 'I<3cs178!'
db = 'Chinook'
