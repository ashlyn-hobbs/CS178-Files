# Name: Ashlyn Hobbs
# Description: a simple hello world program


print("Hello World!")

def add_numbers(num1, num2):
    
    sum = num1 + num2
    
    return sum
    
print(add_numbers(1,2))
    
    